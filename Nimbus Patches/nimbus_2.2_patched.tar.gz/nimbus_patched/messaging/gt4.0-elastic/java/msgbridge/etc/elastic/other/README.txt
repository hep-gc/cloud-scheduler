This directory contains the authorative configuration sources (starting with
"main.xml" that point into the conf settings in the directory above.  Also
contains some internal things.

You shouldn't need to do anything in this directory unless you were specifically
directed to by documentation, are making extensions or doing something esoteric
(or just having fun ;-)).