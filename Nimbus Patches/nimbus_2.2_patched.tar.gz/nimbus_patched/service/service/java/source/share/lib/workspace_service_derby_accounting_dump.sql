select * from deployments;
disconnect;
exit;
