-- uncomment what is of interest

-- select * from resources;
-- select * from staging;
-- select * from vms;
-- select * from groupresources;
-- select * from vm_partitions;
-- select * from vm_deployment;
-- select * from associations;
-- select * from association_entries;
-- select * from resourcepools;
-- select * from resourcepool_entries;
-- select * from default_scheduler_current_tasks;
-- select * from default_scheduler_workspid;
-- select * from pilot_slots;
-- select * from pilot_groups;
-- select * from pilot_notification_position;
-- select * from counter;
-- select * from notification_position;


disconnect;
exit;
